// ../tile-loader/dist/lib/el.js
function el(n, attrs, kids, p) {
  const e = document.createElement(n);
  Object.entries(attrs || {}).forEach(([k, v]) => {
    if (v == null)
      return;
    if (k === "style") {
      Object.entries(v).forEach(([prop, value]) => {
        const snake = prop.split("-").map((part, idx) => idx ? part.charAt(0).toUpperCase() + part.slice(1) : part).join("");
        e.style[snake] = value;
      });
      return;
    }
    e.setAttribute(k, String(v));
  });
  (kids || []).forEach((n2) => {
    if (typeof n2 === "string")
      e.append(txt(n2));
    else
      e.append(n2);
  });
  if (p)
    p.append(e);
  return e;
}
function txt(str2) {
  return document.createTextNode(str2);
}

// ../tile-lexicon/dist/policy.js
var tileSandbox = "allow-downloads allow-forms allow-modals allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts";
var own = `'self' blob: data:`;
var tileCSP = [
  `default-src ${own}`,
  `script-src ${own} 'unsafe-inline' 'unsafe-eval' 'wasm-unsafe-eval'`,
  `style-src ${own} 'unsafe-inline'`,
  `connect-src ${own}`,
  `frame-src ${own}`,
  `form-action 'self'`,
  `object-src 'none'`,
  `base-uri 'self'`,
  `webrtc 'block'`,
  `sandbox ${tileSandbox}`
].join("; ");
var runtimeCSP = [
  `default-src 'self'`,
  `script-src 'self'`,
  `script-src-attr 'none'`,
  `style-src 'self' 'unsafe-inline'`,
  `img-src 'self' data:`,
  `connect-src 'none'`,
  `frame-src 'self'`,
  `worker-src 'self'`,
  `form-action 'none'`,
  `object-src 'none'`,
  `base-uri 'none'`,
  `manifest-src 'none'`,
  `webrtc 'block'`,
  `sandbox ${tileSandbox}`
].join("; ");
var deadCSP = `default-src 'none'; form-action 'none'; base-uri 'none'; frame-ancestors 'none'; sandbox`;
var tileOriginHeaders = {
  "origin-agent-cluster": "?1",
  "referrer-policy": "no-referrer",
  "permissions-policy": "interest-cohort=(), browsing-topics=()",
  "cross-origin-resource-policy": "cross-origin",
  "cross-origin-opener-policy": "same-origin",
  "x-content-type-options": "nosniff",
  "x-dns-prefetch-control": "off",
  "tk": "N",
  "x-robots-tag": "noai, noimageai"
};
var runtimeHeaders = {
  ...tileOriginHeaders,
  "service-worker-allowed": "/",
  "content-security-policy": runtimeCSP
};
var deadHeaders = {
  ...tileOriginHeaders,
  "content-security-policy": deadCSP
};
function localLinks(link) {
  const kept = link.split(/,(?=\s*<)/).map((s) => s.trim()).filter((s) => {
    const target = s.match(/^<([^>]*)>/)?.[1];
    return !!target && !/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i.test(target);
  });
  return kept.length ? kept.join(", ") : void 0;
}
function tileResponseHeaders(headers = {}) {
  const { "speculation-rules": _rules, link, "content-security-policy": ownCSP, ...rest } = headers;
  const out = { "referrer-policy": "no-referrer", ...rest };
  const localLink = link && localLinks(link);
  if (localLink)
    out.link = localLink;
  out["content-security-policy"] = ownCSP ? `${ownCSP}, ${tileCSP}` : tileCSP;
  out["x-content-type-options"] = "nosniff";
  out["x-dns-prefetch-control"] = "off";
  return out;
}

// ../tile-loader/dist/index.js
var TILES_PFX = "tiles-";
var SHUTTLE_PFX = "tiles-shuttle-";
var SND_SHUTTLE_LOAD = `${SHUTTLE_PFX}load`;
var RCV_SHUTTLE_READY = `${SHUTTLE_PFX}ready`;
var SND_SET_TITLE = `${SHUTTLE_PFX}set-title`;
var SND_SET_ICON = `${SHUTTLE_PFX}set-icon`;
var WORKER_PFX = "tiles-worker-";
var SND_WORKER_LOAD = `${WORKER_PFX}load`;
var RCV_WORKER_READY = `${WORKER_PFX}ready`;
var RCV_WORKER_REQUEST = `${WORKER_PFX}request`;
var SND_WORKER_RESPONSE = `${WORKER_PFX}response`;
var TILES_WARNING = `${TILES_PFX}warn`;
var TILES_ERROR = `${TILES_PFX}error`;
var PROTOCOL_UP = "tiles-protocol-up-";
var PROTOCOL_DOWN = "tiles-protocol-down-";
var TileMothership = class {
  #loaders = [];
  #conf;
  #id2shuttle = /* @__PURE__ */ new Map();
  #id2tile = /* @__PURE__ */ new Map();
  constructor(conf = {}) {
    this.#conf = conf;
  }
  init() {
    window.addEventListener("message", async (ev) => {
      const { action } = ev.data || {};
      if (action === TILES_WARNING) {
        const { msg, id } = ev.data;
        console.warn(`[W:${id}]`, ...msg);
      }
      if (action === TILES_ERROR) {
        const { msg, id } = ev.data;
        console.error(`[S:${id}]`, ...msg);
      } else if (action === RCV_SHUTTLE_READY) {
        const { id } = ev.data;
        this.sendToShuttle(id, SND_WORKER_LOAD, { id });
      } else if (action === RCV_WORKER_READY) {
        const { id } = ev.data;
        const tile = this.#id2tile.get(id);
        if (!tile)
          throw new Error(`No tile shuttle with ID ${id}`);
        tile.dispatchEvent(new Event("load"));
      } else if (action === RCV_WORKER_REQUEST) {
        const { type, id, payload } = ev.data;
        if (type === "resolve-path") {
          const { path, requestId } = payload;
          const tile = this.#id2tile.get(id);
          if (!tile)
            throw new Error(`No tile shuttle with ID ${id}`);
          const res = await tile.resolvePath(path);
          const response = res.ok ? { status: res.status, headers: this.hardenResponse(res.headers), body: res.body } : { status: res.status, headers: this.hardenResponse({ "content-type": "text/plain" }), body: void 0 };
          this.sendToShuttle(id, SND_WORKER_RESPONSE, { requestId, response });
        }
      } else if (typeof action === "string" && action.startsWith(PROTOCOL_UP)) {
        const tile = this.tileForWindow(ev.source);
        if (!tile)
          return;
        const rest = action.slice(PROTOCOL_UP.length);
        const dash = rest.indexOf("-");
        if (dash < 1)
          return;
        const protocol = rest.slice(0, dash);
        const kind = rest.slice(dash + 1);
        const { payload } = ev.data;
        tile.dispatchEvent(Object.assign(new Event("protocol"), { protocol, kind, payload }));
        if (protocol === "data") {
          tile.dispatchEvent(Object.assign(new Event(kind === "payload" ? "data" : `data-${kind}`), { payload }));
        }
      }
    });
  }
  /**
   * The headers a tile document ships with: the resource's own, plus the
   * policy from @dasl/tile-lexicon. A host that wants more on every response
   * overrides this and calls super; nothing should ever return less.
   */
  hardenResponse(headers) {
    return tileResponseHeaders(headers);
  }
  tileForWindow(source) {
    if (!source)
      return;
    for (const [id, ifr] of this.#id2shuttle) {
      if (ifr.contentWindow === source)
        return this.#id2tile.get(id);
    }
  }
  sendToShuttle(id, action, payload) {
    const ifr = this.#id2shuttle.get(id);
    if (!ifr)
      return console.error(`No shuttle for ID ${id}`);
    ifr.contentWindow?.postMessage({ id, action, payload }, "*");
  }
  registerShuttleFrame(ifr, tile) {
    const id = crypto.randomUUID();
    this.#id2shuttle.set(id, ifr);
    this.#id2tile.set(id, tile);
    return id;
  }
  startShuttle(id) {
    this.sendToShuttle(id, SND_SHUTTLE_LOAD, { id, webrtcGuard: this.#conf.webrtcGuard ?? "exhaust" });
  }
  // Adds a loader that will handle matching requests to load a tile.
  // - `loader` is an object that knows how to load a tile for a specific scheme
  //    (and types)
  addLoader(loader) {
    this.#loaders.push(loader);
  }
  // Remove using same reference.
  removeLoader(loader) {
    this.#loaders = this.#loaders.filter((ldr) => ldr !== loader);
  }
  getLoadSource() {
    const domain = this.#conf.loadDomain || "load.webtil.es";
    const base = /^https?:\/\//.test(domain) ? domain : `https://${domain}`;
    return new URL("/.well-known/web-tiles/", base).href;
  }
  // Load a tile.
  async loadTile(url) {
    for (const ldr of this.#loaders) {
      const tile = await ldr.load(url, this);
      if (tile)
        return tile;
    }
    return false;
  }
};
var Tile = class extends EventTarget {
  #mothership;
  #url;
  #manifest;
  #pathLoader;
  #shuttleId;
  constructor(mothership, url, manifest, pathLoader) {
    super();
    this.#mothership = mothership;
    this.#url = url;
    this.#manifest = manifest;
    this.#pathLoader = pathLoader;
    this.addEventListener("load", () => {
      if (this.#manifest?.name) {
        const title = this.#manifest?.name;
        this.#mothership.sendToShuttle(this.#shuttleId, SND_SET_TITLE, { title });
        const ev = new Event("title-change");
        ev.title = title;
        this.dispatchEvent(ev);
      }
      const icon = this.#manifest?.icons?.[0]?.src;
      if (icon) {
        this.#mothership.sendToShuttle(this.#shuttleId, SND_SET_ICON, { path: icon });
      }
    });
  }
  get url() {
    return this.#url;
  }
  get manifest() {
    return this.#manifest;
  }
  async resolvePath(path) {
    const u = new URL(`fake:${path}`);
    return this.#pathLoader.resolvePath(u.pathname);
  }
  async renderCard(options) {
    const card = el("div", { style: {
      border: "1px solid lightgrey",
      "border-radius": "3px",
      cursor: "pointer"
    } });
    card.addEventListener("click", async () => {
      const tileRenderer = await this.renderContent(options?.contentHeight || this.#manifest?.sizing?.height || Math.max(card.offsetHeight, 300));
      card.replaceWith(tileRenderer);
    });
    if (this.#manifest?.screenshots?.[0]?.src) {
      const res = await this.resolvePath(this.#manifest.screenshots[0].src);
      if (res.ok) {
        const blob = new Blob([res.body], { type: res.headers?.["content-type"] });
        const url = URL.createObjectURL(blob);
        el("div", { style: {
          "background-image": `url(${url})`,
          "background-size": "cover",
          "background-position": "50%",
          "aspect-ratio": "16/9"
        } }, [], card);
      }
    }
    const title = el("div", { style: {
      padding: "0.5rem 1rem",
      display: "flex",
      "align-items": "center"
    } }, [], card);
    if (this.#manifest?.icons?.[0]?.src) {
      const res = await this.resolvePath(this.#manifest.icons[0].src);
      if (res.ok) {
        const blob = new Blob([res.body], { type: res.headers?.["content-type"] });
        const url = URL.createObjectURL(blob);
        el("img", { src: url, width: "48", height: "48", alt: "icon", style: { "padding-right": "0.5rem" } }, [], title);
      }
    }
    el("span", { style: { "font-weight": "bold" } }, [this.#manifest.name || "Untitled Tile"], title);
    if (this.#manifest.description) {
      el("p", { style: { "margin": "0.5rem 1rem 1rem 1rem" } }, [this.#manifest.description], card);
    }
    return card;
  }
  getLoadSource() {
    return this.#mothership.getLoadSource();
  }
  /**
   * Sends a tiles-protocol message down to the rendered tile. Messages the
   * tile sends up arrive as `protocol` events (and, for tp-data, as `data`
   * and `data-ready` events) on this object.
   */
  sendProtocol(protocol, kind, payload) {
    if (!this.#shuttleId)
      throw new Error("The tile is not rendered yet.");
    this.#mothership.sendToShuttle(this.#shuttleId, `${PROTOCOL_DOWN}${protocol}-${kind}`, payload);
  }
  /** Sends a tp-data payload to the tile (https://dasl.ing/tp-data.html). */
  sendData(payload) {
    this.sendProtocol("data", "payload", payload);
  }
  attachIframe(ifr) {
    this.#shuttleId = this.#mothership.registerShuttleFrame(ifr, this);
    ifr.addEventListener("load", () => this.#mothership.startShuttle(this.#shuttleId));
  }
  renderContent(height = 300) {
    const ifr = el("iframe", {
      src: this.#mothership.getLoadSource(),
      style: {
        display: "block",
        width: "100%",
        height: `${height}px`,
        border: "none"
      }
    });
    this.attachIframe(ifr);
    return ifr;
  }
};

// ../tile-loader/dist/lib/masl.js
var NOT_FOUND = { ok: false, status: 404, statusText: "Not found" };
var maslHeaders = [
  "content-disposition",
  "content-encoding",
  "content-language",
  "content-security-policy",
  "content-type",
  "link",
  "permissions-policy",
  "referrer-policy",
  "service-worker-allowed",
  "sourcemap",
  "speculation-rules",
  "supports-loading-mode",
  "x-content-type-options"
];
function maslResponse(masl, body) {
  if (!body)
    return NOT_FOUND;
  const headers = {};
  maslHeaders.forEach((k) => {
    if (typeof masl[k] !== "undefined")
      headers[k] = masl[k];
  });
  if (typeof body === "string")
    body = new TextEncoder().encode(body);
  return { ok: true, status: 200, statusText: "Ok", headers, body };
}

// ../tile-loader/dist/at.js
async function did2pds(fetch, did) {
  if (!/^did:plc:/.test(did))
    return false;
  const res = await fetch(`https://plc.directory/${did}`);
  if (!res.ok)
    return false;
  const doc = await res.json();
  const pds = doc.service?.find((s) => s.id === "#atproto_pds")?.serviceEndpoint;
  return pds;
}
async function fetchFromPDS(fetch, did, query, params2) {
  const pds = await did2pds(fetch, did);
  if (!pds)
    return;
  const url = new URL(pds);
  url.pathname = `/xrpc/${query}`;
  const prm = url.searchParams;
  Object.entries(params2).forEach(([k, v]) => prm.set(k, v));
  return await fetch(url.toString());
}
async function getRecord(fetch, repo, collection, rkey) {
  const res = await fetchFromPDS(fetch, repo, "com.atproto.repo.getRecord", { repo, collection, rkey });
  if (!res || !res.ok)
    return false;
  return await res.json();
}
async function getBlob(fetch, did, cid) {
  const res = await fetchFromPDS(fetch, did, "com.atproto.sync.getBlob", { did, cid });
  if (!res || !res.ok)
    return false;
  return await res.arrayBuffer();
}
var ATTileLoader = class {
  #fetch;
  constructor(options = {}) {
    this.#fetch = options.fetch ?? ((...args) => globalThis.fetch(...args));
  }
  async load(url, mothership) {
    if (!/^at:\/\//.test(url))
      return false;
    const [repo, collection, rkey] = url.replace(/^at:\/\//, "").split("/");
    if (collection !== "ing.dasl.masl")
      return;
    const res = await getRecord(this.#fetch, repo, collection, rkey);
    if (!res)
      return false;
    const manifest = res.value?.tile;
    if (!manifest)
      return false;
    const loader = new ATPathLoader(repo, manifest, this.#fetch);
    return new Tile(mothership, url, manifest, loader);
  }
};
var ATPathLoader = class {
  #did;
  #manifest;
  #fetch;
  constructor(did, manifest, fetch = (...args) => globalThis.fetch(...args)) {
    this.#did = did;
    this.#manifest = manifest;
    this.#fetch = fetch;
  }
  async resolvePath(path) {
    const entry = this.#manifest?.resources?.[path];
    if (!entry?.src)
      return NOT_FOUND;
    const src = entry.src;
    const cid = "$link" in src ? src.$link : src.ref.$link;
    const data = await getBlob(this.#fetch, this.#did, cid);
    if (!data)
      return NOT_FOUND;
    return maslResponse(entry, data);
  }
};

// ../node_modules/@atcute/uint8array/dist/index.js
var textEncoder = new TextEncoder();
var textDecoder = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true });
var subtle = crypto.subtle;
var _fromCharCode = String.fromCharCode;
var _shortString = (from, p, length) => {
  if (length < 4) {
    if (length < 2) {
      if (length === 0) {
        return "";
      }
      const a3 = from[p];
      if (a3 & 128) {
        return null;
      }
      return _fromCharCode(a3);
    }
    const a2 = from[p];
    const b2 = from[p + 1];
    if ((a2 | b2) & 128) {
      return null;
    }
    if (length === 2) {
      return _fromCharCode(a2, b2);
    }
    const c2 = from[p + 2];
    if (c2 & 128) {
      return null;
    }
    return _fromCharCode(a2, b2, c2);
  }
  const a = from[p];
  const b = from[p + 1];
  const c = from[p + 2];
  const d = from[p + 3];
  if ((a | b | c | d) & 128) {
    return null;
  }
  if (length < 8) {
    if (length === 4) {
      return _fromCharCode(a, b, c, d);
    }
    const e2 = from[p + 4];
    if (e2 & 128) {
      return null;
    }
    if (length === 5) {
      return _fromCharCode(a, b, c, d, e2);
    }
    const f2 = from[p + 5];
    if (f2 & 128) {
      return null;
    }
    if (length === 6) {
      return _fromCharCode(a, b, c, d, e2, f2);
    }
    const g2 = from[p + 6];
    if (g2 & 128) {
      return null;
    }
    return _fromCharCode(a, b, c, d, e2, f2, g2);
  }
  const e = from[p + 4];
  const f = from[p + 5];
  const g = from[p + 6];
  const h = from[p + 7];
  if ((e | f | g | h) & 128) {
    return null;
  }
  if (length < 12) {
    if (length === 8) {
      return _fromCharCode(a, b, c, d, e, f, g, h);
    }
    const i2 = from[p + 8];
    if (i2 & 128) {
      return null;
    }
    if (length === 9) {
      return _fromCharCode(a, b, c, d, e, f, g, h, i2);
    }
    const j2 = from[p + 9];
    if (j2 & 128) {
      return null;
    }
    if (length === 10) {
      return _fromCharCode(a, b, c, d, e, f, g, h, i2, j2);
    }
    const k2 = from[p + 10];
    if (k2 & 128) {
      return null;
    }
    return _fromCharCode(a, b, c, d, e, f, g, h, i2, j2, k2);
  }
  const i = from[p + 8];
  const j = from[p + 9];
  const k = from[p + 10];
  const l = from[p + 11];
  if ((i | j | k | l) & 128) {
    return null;
  }
  if (length === 12) {
    return _fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l);
  }
  const m = from[p + 12];
  if (m & 128) {
    return null;
  }
  if (length === 13) {
    return _fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m);
  }
  const n = from[p + 13];
  if (n & 128) {
    return null;
  }
  if (length === 14) {
    return _fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m, n);
  }
  const o = from[p + 14];
  if (o & 128) {
    return null;
  }
  return _fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o);
};
var decodeUtf8From = (from, offset = 0, length = from.length - offset) => {
  if (length <= 15) {
    const result = _shortString(from, offset, length);
    if (result !== null) {
      return result;
    }
  }
  if (offset === 0 && length === from.length) {
    return textDecoder.decode(from);
  }
  return textDecoder.decode(from.subarray(offset, offset + length));
};

// ../node_modules/@atcute/multibase/dist/utils.js
var createRfc4648Encode = (alphabet, bitsPerChar, pad) => {
  return (bytes) => {
    const mask = (1 << bitsPerChar) - 1;
    let str2 = "";
    let bits = 0;
    let buffer = 0;
    for (let i = 0; i < bytes.length; ++i) {
      buffer = buffer << 8 | bytes[i];
      bits += 8;
      while (bits > bitsPerChar) {
        bits -= bitsPerChar;
        str2 += alphabet[mask & buffer >> bits];
      }
    }
    if (bits !== 0) {
      str2 += alphabet[mask & buffer << bitsPerChar - bits];
    }
    if (pad) {
      while ((str2.length * bitsPerChar & 7) !== 0) {
        str2 += "=";
      }
    }
    return str2;
  };
};

// ../node_modules/@atcute/multibase/dist/bases/base64-web-native.js
var toBase64 = (bytes) => {
  return bytes.toBase64({ alphabet: "base64", omitPadding: true });
};

// ../node_modules/@atcute/multibase/dist/bases/base64-web-polyfill.js
var BASE64_CHARSET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var toBase642 = /* @__PURE__ */ createRfc4648Encode(BASE64_CHARSET, 6, false);

// ../node_modules/@atcute/multibase/dist/bases/base64-web.js
var HAS_NATIVE_SUPPORT = "fromBase64" in Uint8Array;
var toBase643 = !HAS_NATIVE_SUPPORT ? toBase642 : toBase64;

// ../node_modules/@atcute/multibase/dist/bases/base32-encode.js
var ALPHABET = "abcdefghijklmnopqrstuvwxyz234567";
var _cc = /* @__PURE__ */ (() => {
  const t = new Uint8Array(32);
  for (let i = 0; i < 32; i++) {
    t[i] = ALPHABET.charCodeAt(i);
  }
  return t;
})();
var _fromCharCode2 = String.fromCharCode;
var toBase32 = (bytes) => {
  const len = bytes.length;
  const full = len / 5 | 0;
  const rem = len - full * 5;
  const cc = _cc;
  let str2 = "";
  let ip = 0;
  const pairs = full / 2 | 0;
  for (let g = 0; g < pairs; g++) {
    const a0 = bytes[ip], a1 = bytes[ip + 1], a2 = bytes[ip + 2], a3 = bytes[ip + 3], a4 = bytes[ip + 4];
    const b0 = bytes[ip + 5], b1 = bytes[ip + 6], b2 = bytes[ip + 7], b3 = bytes[ip + 8], b4 = bytes[ip + 9];
    str2 += _fromCharCode2(cc[a0 >>> 3], cc[(a0 << 2 | a1 >>> 6) & 31], cc[a1 >>> 1 & 31], cc[(a1 << 4 | a2 >>> 4) & 31], cc[(a2 << 1 | a3 >>> 7) & 31], cc[a3 >>> 2 & 31], cc[(a3 << 3 | a4 >>> 5) & 31], cc[a4 & 31], cc[b0 >>> 3], cc[(b0 << 2 | b1 >>> 6) & 31], cc[b1 >>> 1 & 31], cc[(b1 << 4 | b2 >>> 4) & 31], cc[(b2 << 1 | b3 >>> 7) & 31], cc[b3 >>> 2 & 31], cc[(b3 << 3 | b4 >>> 5) & 31], cc[b4 & 31]);
    ip += 10;
  }
  if (full & 1) {
    const b0 = bytes[ip], b1 = bytes[ip + 1], b2 = bytes[ip + 2], b3 = bytes[ip + 3], b4 = bytes[ip + 4];
    str2 += _fromCharCode2(cc[b0 >>> 3], cc[(b0 << 2 | b1 >>> 6) & 31], cc[b1 >>> 1 & 31], cc[(b1 << 4 | b2 >>> 4) & 31], cc[(b2 << 1 | b3 >>> 7) & 31], cc[b3 >>> 2 & 31], cc[(b3 << 3 | b4 >>> 5) & 31], cc[b4 & 31]);
    ip += 5;
  }
  if (rem > 0) {
    let buffer = 0;
    let bits = 0;
    for (let i = ip; i < len; i++) {
      buffer = buffer << 8 | bytes[i];
      bits += 8;
    }
    while (bits >= 5) {
      bits -= 5;
      str2 += _fromCharCode2(cc[buffer >>> bits & 31]);
    }
    if (bits > 0) {
      str2 += _fromCharCode2(cc[buffer << 5 - bits & 31]);
    }
  }
  return str2;
};

// ../node_modules/@atcute/cid/dist/codec.js
var CID_VERSION = 1;
var HASH_SHA256 = 18;
var CODEC_RAW = 85;
var CODEC_DCBOR = 113;
var decodeFirst = (bytes) => {
  if (bytes.length < 36) {
    throw new RangeError(`cid too short`);
  }
  const version = bytes[0];
  const codec = bytes[1];
  const digestType = bytes[2];
  const digestSize = bytes[3];
  if (version !== CID_VERSION) {
    throw new RangeError(`incorrect cid version (got v${version})`);
  }
  if (codec !== CODEC_DCBOR && codec !== CODEC_RAW) {
    throw new RangeError(`incorrect cid codec (got 0x${codec.toString(16)})`);
  }
  if (digestType !== HASH_SHA256) {
    throw new RangeError(`incorrect cid digest codec (got 0x${digestType.toString(16)})`);
  }
  if (digestSize !== 32) {
    throw new RangeError(`incorrect cid digest size (got ${digestSize})`);
  }
  const cid = {
    version: CID_VERSION,
    codec,
    digest: {
      codec: digestType,
      contents: bytes.subarray(4, 36)
    },
    bytes: bytes.subarray(0, 36)
  };
  return [cid, bytes.subarray(36)];
};
var decode = (bytes) => {
  const [cid, remainder] = decodeFirst(bytes);
  if (remainder.length !== 0) {
    throw new RangeError(`cid bytes includes remainder`);
  }
  return cid;
};
var toString = (cid) => {
  return `b${toBase32(cid.bytes)}`;
};
var fromBinary = (input) => {
  if (input.length !== 37 || input[0] !== 0) {
    throw new SyntaxError(`invalid binary cid`);
  }
  return decode(input.subarray(1));
};

// ../node_modules/@atcute/cid/dist/cid-link.js
var CID_LINK_SYMBOL = Symbol.for("@atcute/cid-link-wrapper");
var CidLinkWrapper = class {
  /** @internal */
  [CID_LINK_SYMBOL] = true;
  bytes;
  constructor(bytes) {
    this.bytes = bytes;
  }
  get $link() {
    const link = `b${toBase32(this.bytes)}`;
    Object.defineProperty(this, "$link", {
      value: link,
      enumerable: true
    });
    return link;
  }
  toJSON() {
    return { $link: this.$link };
  }
};
var toCidLink = (cid) => {
  return new CidLinkWrapper(cid.bytes);
};

// ../node_modules/@atcute/cbor/dist/bytes.js
var BYTES_SYMBOL = Symbol.for("@atcute/bytes-wrapper");
var BytesWrapper = class {
  /** @internal */
  [BYTES_SYMBOL] = true;
  buf;
  constructor(buf) {
    this.buf = buf;
  }
  get $bytes() {
    return toBase643(this.buf);
  }
  toJSON() {
    return { $bytes: this.$bytes };
  }
};
var toBytes = (buf) => {
  return new BytesWrapper(buf);
};

// ../node_modules/@atcute/cbor/dist/decode.js
var MAX_RETAINED_BUFFER_RATIO = 8;
var requireBytes = (state, needed) => {
  if (needed > state.b.length - state.p) {
    throw new RangeError(`unexpected end of input`);
  }
};
var readArgument = (state, info) => {
  if (info < 24) {
    return info;
  }
  let arg;
  switch (info) {
    case 24: {
      requireBytes(state, 1);
      arg = readUint8(state);
      if (arg < 24) {
        throw new TypeError(`non-canonical argument encoding`);
      }
      break;
    }
    case 25: {
      requireBytes(state, 2);
      arg = readUint16(state);
      if (arg < 256) {
        throw new TypeError(`non-canonical argument encoding`);
      }
      break;
    }
    case 26: {
      requireBytes(state, 4);
      arg = readUint32(state);
      if (arg < 65536) {
        throw new TypeError(`non-canonical argument encoding`);
      }
      break;
    }
    case 27: {
      requireBytes(state, 8);
      arg = readUint53(state);
      if (arg < 4294967296) {
        throw new TypeError(`non-canonical argument encoding`);
      }
      break;
    }
    default: {
      throw new Error(`invalid argument encoding; got ${info}`);
    }
  }
  return arg;
};
var readFloat64 = (state) => {
  requireBytes(state, 8);
  const view = state.v ??= new DataView(state.b.buffer, state.b.byteOffset, state.b.byteLength);
  const value = view.getFloat64(state.p);
  if (!Number.isFinite(value)) {
    throw new RangeError(`NaN and Infinity values not supported`);
  }
  state.p += 8;
  return value;
};
var readUint8 = (state) => {
  return state.b[state.p++];
};
var readUint16 = (state) => {
  let pos = state.p;
  const buf = state.b;
  const value = buf[pos++] << 8 | buf[pos++];
  state.p = pos;
  return value;
};
var readUint32 = (state) => {
  let pos = state.p;
  const buf = state.b;
  const value = (buf[pos++] << 24 | buf[pos++] << 16 | buf[pos++] << 8 | buf[pos++]) >>> 0;
  state.p = pos;
  return value;
};
var readUint53 = (state) => {
  const hi = readUint32(state);
  const lo = readUint32(state);
  if (hi > 2097151) {
    throw new RangeError(`can't decode integers beyond safe integer range`);
  }
  return hi * 2 ** 32 + lo;
};
var readString = (state, length) => {
  requireBytes(state, length);
  const string = decodeUtf8From(state.b, state.p, length);
  state.p += length;
  return string;
};
var readBytes = (state, length) => {
  requireBytes(state, length);
  const slice = state.b.subarray(state.p, state.p += length);
  return toBytes(length * MAX_RETAINED_BUFFER_RATIO <= slice.buffer.byteLength ? new Uint8Array(slice) : slice);
};
var readCid = (state, length) => {
  requireBytes(state, length);
  const buf = state.b;
  const pos = state.p;
  if (length !== 37 || buf[pos] !== 0 || buf[pos + 1] !== CID_VERSION || buf[pos + 2] !== CODEC_DCBOR && buf[pos + 2] !== CODEC_RAW || buf[pos + 3] !== HASH_SHA256 || buf[pos + 4] !== 32) {
    const cid = fromBinary(new Uint8Array(buf.subarray(pos, state.p += length)));
    return new CidLinkWrapper(cid.bytes);
  }
  const bytes = new Uint8Array(36);
  for (let i = 0; i < 36; i++) {
    bytes[i] = buf[pos + 1 + i];
  }
  state.p = pos + length;
  return new CidLinkWrapper(bytes);
};
var decodeStringKey = (state) => {
  requireBytes(state, 1);
  const prelude = readUint8(state);
  const type = prelude >> 5;
  if (type !== 3) {
    throw new TypeError(`expected map to only have string keys; got type ${type}`);
  }
  const info = prelude & 31;
  const length = info < 24 ? info : readArgument(state, info);
  state.ks = state.p;
  state.kl = length;
  return readString(state, length);
};
var decodeFirst2 = (buf) => {
  const len = buf.length;
  const state = {
    b: buf,
    v: null,
    p: 0,
    ks: 0,
    kl: 0
  };
  let stack = null;
  let value;
  jump: while (state.p < len) {
    const prelude = readUint8(state);
    const type = prelude >> 5;
    const info = prelude & 31;
    const arg = type === 7 ? 0 : info < 24 ? info : readArgument(state, info);
    switch (type) {
      case 0: {
        value = arg;
        break;
      }
      case 1: {
        value = -1 - arg;
        if (value < Number.MIN_SAFE_INTEGER) {
          throw new RangeError(`can't decode integers beyond safe integer range`);
        }
        break;
      }
      case 2: {
        value = readBytes(state, arg);
        break;
      }
      case 3: {
        value = readString(state, arg);
        break;
      }
      case 4: {
        if (arg > 0) {
          requireBytes(state, arg);
          stack = { t: 1, c: value = new Array(arg), k: null, r: arg, n: stack };
          continue jump;
        }
        value = [];
        break;
      }
      case 5: {
        value = {};
        if (arg > 0) {
          const first = decodeStringKey(state);
          stack = { t: 0, c: value, k: first, ks: state.ks, kl: state.kl, r: arg, n: stack };
          continue jump;
        }
        break;
      }
      case 6: {
        switch (arg) {
          case 42: {
            requireBytes(state, 1);
            const prelude2 = readUint8(state);
            const type2 = prelude2 >> 5;
            const info2 = prelude2 & 31;
            if (type2 !== 2) {
              throw new TypeError(`expected cid-link to be type 2 (bytes); got type ${type2}`);
            }
            const len2 = readArgument(state, info2);
            value = readCid(state, len2);
            break;
          }
          default: {
            throw new TypeError(`unsupported tag; got ${arg}`);
          }
        }
        break;
      }
      case 7: {
        switch (info) {
          case 20:
          case 21: {
            value = info === 21;
            break;
          }
          case 22: {
            value = null;
            break;
          }
          case 27: {
            value = readFloat64(state);
            break;
          }
          default: {
            throw new Error(`invalid simple value; got ${info}`);
          }
        }
        break;
      }
      default: {
        throw new TypeError(`invalid type; got ${type}`);
      }
    }
    while (stack !== null) {
      switch (stack.t) {
        case 0: {
          const obj = stack.c;
          const key = stack.k;
          if (key === "__proto__") {
            Object.defineProperty(obj, key, { enumerable: true, configurable: true, writable: true });
          }
          obj[key] = value;
          break;
        }
        case 1: {
          const arr = stack.c;
          const index = arr.length - stack.r;
          arr[index] = value;
          break;
        }
      }
      if (--stack.r) {
        if (!stack.t) {
          const prevStart = stack.ks;
          const prevLength = stack.kl;
          stack.k = decodeStringKey(state);
          const curStart = state.ks;
          const curLength = state.kl;
          let cmp = curLength - prevLength;
          if (cmp === 0) {
            const buf2 = state.b;
            for (let i = 0; i < curLength; i++) {
              cmp = buf2[curStart + i] - buf2[prevStart + i];
              if (cmp !== 0) {
                break;
              }
            }
          }
          if (cmp <= 0) {
            throw new TypeError(`map keys are not in canonical order or contain duplicates`);
          }
          stack.ks = curStart;
          stack.kl = curLength;
        }
        continue jump;
      }
      value = stack.c;
      stack = stack.n;
    }
    return [value, buf.subarray(state.p)];
  }
  throw new RangeError(`unexpected end of input`);
};
var decode2 = (buf) => {
  const [value, remainder] = decodeFirst2(buf);
  if (remainder.length !== 0) {
    throw new Error(`decoded value contains remainder`);
  }
  return value;
};

// ../node_modules/@atcute/varint/dist/index.js
var MSB = 128;
var REST = 127;
var MSBALL = ~REST;
var INT = 2 ** 31;
var N1 = 2 ** 7;
var N2 = 2 ** 14;
var N3 = 2 ** 21;
var N4 = 2 ** 28;
var N5 = 2 ** 35;
var N6 = 2 ** 42;
var N7 = 2 ** 49;
var N8 = 2 ** 56;
var N9 = 2 ** 63;
var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER;
var _min = Math.min;
var decode3 = (buf, offset = 0, length = buf.length) => {
  const end = _min(offset + length, buf.length);
  let counter = offset;
  if (counter >= end) {
    throw new RangeError("could not decode varint");
  }
  let b = buf[counter++];
  let res = b & REST;
  if (b < MSB) {
    return { value: res, nextOffset: counter };
  }
  if (counter >= end) {
    throw new RangeError("could not decode varint");
  }
  b = buf[counter++];
  res |= (b & REST) << 7;
  if (b < MSB) {
    return { value: res, nextOffset: counter };
  }
  if (counter >= end) {
    throw new RangeError("could not decode varint");
  }
  b = buf[counter++];
  res |= (b & REST) << 14;
  if (b < MSB) {
    return { value: res, nextOffset: counter };
  }
  if (counter >= end) {
    throw new RangeError("could not decode varint");
  }
  b = buf[counter++];
  res |= (b & REST) << 21;
  if (b < MSB) {
    return { value: res, nextOffset: counter };
  }
  if (counter >= end) {
    throw new RangeError("could not decode varint");
  }
  b = buf[counter++];
  res += (b & REST) * N4;
  if (b < MSB) {
    return { value: res, nextOffset: counter };
  }
  let shift = 35;
  do {
    if (counter >= end) {
      throw new RangeError("could not decode varint");
    }
    b = buf[counter++];
    res += (b & REST) * 2 ** shift;
    shift += 7;
  } while (b >= MSB);
  return { value: res, nextOffset: counter };
};

// ../node_modules/@atcute/car/dist/types.js
var isCarV1Header = (value) => {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const { version, roots } = value;
  return version === 1 && Array.isArray(roots) && roots.every((root2) => root2 instanceof CidLinkWrapper);
};

// ../node_modules/@atcute/car/dist/reader.js
var fromUint8Array = (buffer) => {
  const { header, nextOffset: headerOffset } = readHeader(buffer, 0);
  let pos = headerOffset;
  return {
    header,
    roots: header.data.roots,
    [Symbol.iterator]() {
      return {
        next() {
          if (pos >= buffer.length) {
            return {
              done: true,
              value: void 0
            };
          }
          const entryStart = pos;
          const { value: entryLength, nextOffset: lengthOffset } = decode3(buffer, pos, 8);
          pos = lengthOffset;
          const cidStart = pos;
          const { cid, nextOffset: cidOffset } = readCid2(buffer, pos);
          pos = cidOffset;
          const bytesStart = pos;
          const bytesSize = entryLength - (bytesStart - cidStart);
          if (bytesSize < 0 || bytesStart + bytesSize > buffer.length) {
            throw new RangeError("unexpected end of data");
          }
          const bytesEnd = bytesStart + bytesSize;
          const bytes = buffer.subarray(bytesStart, bytesEnd);
          pos = bytesEnd;
          const cidEnd = bytesStart;
          const entryEnd = bytesEnd;
          return {
            done: false,
            value: {
              cid,
              bytes,
              entryStart,
              entryEnd,
              cidStart,
              cidEnd,
              bytesStart,
              bytesEnd
            }
          };
        },
        [Symbol.iterator]() {
          return this;
        }
      };
    }
  };
};
var readHeader = (source, offset) => {
  const headerStart = offset;
  const { value: length, nextOffset: lengthOffset } = decode3(source, offset, 8);
  if (length === 0) {
    throw new RangeError(`invalid car header; length=0`);
  }
  const dataStart = lengthOffset;
  const dataEnd = dataStart + length;
  if (dataEnd > source.length) {
    throw new RangeError("unexpected end of data");
  }
  const data = decode2(source.subarray(dataStart, dataEnd));
  if (!isCarV1Header(data)) {
    throw new TypeError(`expected a car v1 archive`);
  }
  const headerEnd = dataEnd;
  return {
    header: { data, headerStart, headerEnd, dataStart, dataEnd },
    nextOffset: dataEnd
  };
};
var readCid2 = (source, offset) => {
  const cidEnd = offset + 36;
  if (cidEnd > source.length) {
    throw new RangeError("unexpected end of data");
  }
  const bytes = source.subarray(offset, cidEnd);
  const version = bytes[0];
  const codec = bytes[1];
  const digestType = bytes[2];
  const digestSize = bytes[3];
  if (version !== CID_VERSION) {
    throw new RangeError(`incorrect cid version (got v${version})`);
  }
  if (codec !== CODEC_DCBOR && codec !== CODEC_RAW) {
    throw new RangeError(`incorrect cid codec (got 0x${codec.toString(16)})`);
  }
  if (digestType !== HASH_SHA256) {
    throw new RangeError(`incorrect cid digest type (got 0x${digestType.toString(16)})`);
  }
  if (digestSize !== 32) {
    throw new RangeError(`incorrect cid digest size (got ${digestSize})`);
  }
  return {
    cid: {
      version,
      codec,
      digest: {
        codec: digestType,
        contents: bytes.subarray(4, 36)
      },
      bytes
    },
    nextOffset: cidEnd
  };
};

// ../tile-loader/dist/content-scheme.js
var ContentSchemeTileLoader = class {
  #schemes;
  #fetch;
  constructor(schemes = ["http", "file"], options = {}) {
    this.#schemes = new Set(schemes);
    this.#fetch = options.fetch ?? ((...args) => globalThis.fetch(...args));
  }
  async load(url, mothership) {
    let u;
    try {
      u = new URL(url);
    } catch {
      return false;
    }
    if (u.protocol === "https:" || u.protocol === "http:") {
      if (!this.#schemes.has("http"))
        return false;
      const res = await this.#fetch(url);
      if (!res.ok)
        return false;
      return await this.processContent(await res.arrayBuffer(), u.protocol, url, mothership);
    }
    if (u.protocol === "file:") {
      if (!this.#schemes.has("file"))
        return false;
    }
    return void 0;
  }
};

// ../tile-loader/dist/car.js
var CARTileLoader = class extends ContentSchemeTileLoader {
  constructor(schemes, options) {
    super(schemes, options);
  }
  // NOTE: ignoring scheme for now, this is pure HTTP
  async processContent(carData, scheme, url, mothership) {
    let car;
    try {
      car = fromUint8Array(new Uint8Array(carData));
    } catch (e) {
      return false;
    }
    console.warn(`car`, car);
    const { data } = car.header;
    const manifest = data;
    delete manifest.version;
    delete manifest.roots;
    Object.keys(manifest.resources).forEach((k) => {
      manifest.resources[k].src = toCidLink(manifest.resources[k].src).toJSON();
    });
    const offsets = {};
    for await (const entry of car) {
      const { cid, bytesStart, bytesEnd } = entry;
      offsets[toString(cid)] = [bytesStart, bytesEnd];
    }
    const loader = new CARPathLoader(manifest, carData, offsets);
    return new Tile(mothership, url, manifest, loader);
  }
};
var CARPathLoader = class {
  #manifest;
  #carData;
  #offsets;
  constructor(manifest, carData, offsets) {
    this.#manifest = manifest;
    this.#carData = carData;
    this.#offsets = offsets;
  }
  async resolvePath(path) {
    const entry = this.#manifest?.resources?.[path];
    if (!entry?.src)
      return NOT_FOUND;
    const src = entry.src;
    const cid = "$link" in src ? src.$link : src.ref.$link;
    const [start, end] = this.#offsets[cid];
    return maslResponse(entry, this.#carData.slice(start, end));
  }
};

// src/messages.ts
var TILE_HOST_VERSION = 1;
function asMessage(data) {
  if (typeof data === "string") {
    try {
      data = JSON.parse(data);
    } catch {
      return void 0;
    }
  }
  if (!data || typeof data !== "object" || Array.isArray(data)) return void 0;
  const o = data;
  return o.tilesHost === TILE_HOST_VERSION ? o : void 0;
}
var str = (v) => typeof v === "string";
function parseTileHostCommand(data) {
  const o = asMessage(data);
  if (!o) return void 0;
  switch (o.action) {
    case "send-protocol":
      return str(o.protocol) && str(o.kind) ? { tilesHost: 1, action: "send-protocol", protocol: o.protocol, kind: o.kind, payload: o.payload } : void 0;
    case "send-data":
      return { tilesHost: 1, action: "send-data", payload: o.payload };
    default:
      return void 0;
  }
}

// src/browser/host.ts
var params = new URLSearchParams(location.search);
var tileUrl = params.get("tile");
var loadDomain = params.get("load") || defaultLoadDomain();
var root = document.getElementById("tile");
function defaultLoadDomain() {
  const { protocol, hostname, port } = location;
  const host = `load.${hostname}${port ? `:${port}` : ""}`;
  return protocol === "https:" ? host : `${protocol}//${host}`;
}
function emit(event) {
  const data = JSON.stringify(event);
  window.ReactNativeWebView?.postMessage(data);
  if (window.parent !== window) window.parent.postMessage(data, "*");
}
function fail(message) {
  emit({ tilesHost: 1, event: "error", message });
  root.textContent = message;
  root.classList.add("error");
}
function listen(tile) {
  const onMessage = (ev) => {
    const { source, data } = ev;
    if (source && source !== window && source !== window.parent) return;
    const command = parseTileHostCommand(data);
    if (!command) return;
    try {
      if (command.action === "send-protocol") tile.sendProtocol(command.protocol, command.kind, command.payload);
      else tile.sendData(command.payload);
    } catch (e) {
      emit({ tilesHost: 1, event: "error", message: e.message });
    }
  };
  window.addEventListener("message", onMessage);
  document.addEventListener("message", onMessage);
}
async function main() {
  if (!tileUrl) return fail("No tile given: open this page with ?tile=<at:// or https:// URL>.");
  const mothership = new TileMothership({ loadDomain });
  mothership.init();
  mothership.addLoader(new ATTileLoader());
  mothership.addLoader(new CARTileLoader());
  let tile;
  try {
    tile = await mothership.loadTile(tileUrl);
  } catch (e) {
    return fail(`Could not load ${tileUrl}: ${e.message}`);
  }
  if (!tile) return fail(`Nothing knows how to load ${tileUrl}.`);
  const manifest = tile.manifest;
  const name = manifest.name || "Tile";
  document.title = name;
  emit({ tilesHost: 1, event: "manifest", url: tile.url, name: manifest.name, description: manifest.description, sizing: manifest.sizing });
  tile.addEventListener("load", () => emit({ tilesHost: 1, event: "load" }));
  tile.addEventListener("title-change", (ev) => {
    const title = ev.title ?? "";
    document.title = title || name;
    emit({ tilesHost: 1, event: "title", title });
  });
  tile.addEventListener("protocol", (ev) => {
    const { protocol, kind, payload } = ev;
    emit({ tilesHost: 1, event: "protocol", protocol, kind, payload });
  });
  listen(tile);
  const frame = tile.renderContent(manifest.sizing?.height || 300);
  frame.style.height = "100%";
  frame.title = name;
  root.replaceChildren(frame);
}
main().catch((e) => fail(`Could not load ${tileUrl}: ${e.message}`));
