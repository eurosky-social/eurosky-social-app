// The host page: one tile, filling the viewport, for an embedder that cannot
// run the loader itself (a native app's WebView) or would rather not (a site
// embedding a tile in an iframe). The embedder tells it which tile through
// the URL, and the two talk through the message bridge (see ../messages.ts).
//
//   /host/?tile=<at:// or https:// URL>[&load=<loading server>]
//
// The tile runs exactly as it would in a browser page: the mothership here
// frames the shuttle from the loading server on a fresh origin, the worker
// there answers the tile's requests from its own resources, and every
// response carries the policy from @dasl/tile-lexicon.

import { TileMothership } from '@dasl/tile-loader';
import type { Tile, ProtocolEvent } from '@dasl/tile-loader';
import { ATTileLoader } from '@dasl/tile-loader/at';
import { CARTileLoader } from '@dasl/tile-loader/car';
import { parseTileHostCommand } from '../messages.js';
import type { TileHostEvent } from '../messages.js';

declare global {
  interface Window {
    /** Injected by react-native-webview: the channel up to the app. */
    ReactNativeWebView?: { postMessage (data: string): void };
  }
}

const params = new URLSearchParams(location.search);
const tileUrl = params.get('tile');
const loadDomain = params.get('load') || defaultLoadDomain();
const root = document.getElementById('tile') as HTMLElement;

// The loading server is expected next to the page: load.<host>. Off https
// (local development) the scheme and port are kept.
function defaultLoadDomain (): string {
  const { protocol, hostname, port } = location;
  const host = `load.${hostname}${port ? `:${port}` : ''}`;
  return protocol === 'https:' ? host : `${protocol}//${host}`;
}

// Up to the embedder: a WebView's handler if there is one, and the parent
// window if there is one. Both can be absent (the page opened on its own).
function emit (event: TileHostEvent) {
  const data = JSON.stringify(event);
  window.ReactNativeWebView?.postMessage(data);
  if (window.parent !== window) window.parent.postMessage(data, '*');
}

function fail (message: string) {
  emit({ tilesHost: 1, event: 'error', message });
  root.textContent = message;
  root.classList.add('error');
}

// Down from the embedder. A WebView delivers its messages as `message` events
// with no source (iOS dispatches on window, Android on document); a parent
// window is the event's source. Anything else, the shuttle in particular, is
// a window of this page's own making and gets no say.
function listen (tile: Tile) {
  const onMessage = (ev: Event) => {
    const { source, data } = ev as MessageEvent;
    if (source && source !== window && source !== window.parent) return;
    const command = parseTileHostCommand(data);
    if (!command) return;
    try {
      if (command.action === 'send-protocol') tile.sendProtocol(command.protocol, command.kind, command.payload);
      else tile.sendData(command.payload);
    }
    catch (e) {
      emit({ tilesHost: 1, event: 'error', message: (e as Error).message });
    }
  };
  window.addEventListener('message', onMessage);
  document.addEventListener('message', onMessage);
}

async function main () {
  if (!tileUrl) return fail('No tile given: open this page with ?tile=<at:// or https:// URL>.');
  const mothership = new TileMothership({ loadDomain });
  mothership.init();
  mothership.addLoader(new ATTileLoader());
  mothership.addLoader(new CARTileLoader());

  let tile: Tile | false;
  try {
    tile = await mothership.loadTile(tileUrl);
  }
  catch (e) {
    return fail(`Could not load ${tileUrl}: ${(e as Error).message}`);
  }
  if (!tile) return fail(`Nothing knows how to load ${tileUrl}.`);

  const manifest = tile.manifest;
  const name = manifest.name || 'Tile';
  document.title = name;
  emit({ tilesHost: 1, event: 'manifest', url: tile.url, name: manifest.name, description: manifest.description, sizing: manifest.sizing });
  tile.addEventListener('load', () => emit({ tilesHost: 1, event: 'load' }));
  tile.addEventListener('title-change', (ev) => {
    const title = (ev as Event & { title?: string }).title ?? '';
    document.title = title || name;
    emit({ tilesHost: 1, event: 'title', title });
  });
  tile.addEventListener('protocol', (ev) => {
    const { protocol, kind, payload } = ev as ProtocolEvent;
    emit({ tilesHost: 1, event: 'protocol', protocol, kind, payload });
  });
  listen(tile);

  // The embedder owns the size: the frame fills whatever viewport it is given.
  const frame = tile.renderContent(manifest.sizing?.height || 300);
  frame.style.height = '100%';
  frame.title = name;
  root.replaceChildren(frame);
}

main().catch(e => fail(`Could not load ${tileUrl}: ${(e as Error).message}`));
