// The messages between the host page and whatever embeds it: a WebView's
// message channel (`window.ReactNativeWebView.postMessage` up, a `message`
// event down) or a parent window (`postMessage` both ways). Every message is
// the JSON of one of these objects; `tilesHost` names the schema version, so
// that an embedder can tell them from anything else arriving on the channel.
//
// This module has no dependencies and no DOM, so an embedder written in
// TypeScript can import it for the types and the parsers.

export const TILE_HOST_VERSION = 1 as const;

export interface TileHostSizing {
  width: number;
  height: number;
}

/** What the host page tells its embedder. */
export type TileHostEvent =
  /** The tile is known: its manifest's card fields and requested size. Always first. */
  | { tilesHost: 1; event: 'manifest'; url: string; name?: string; description?: string; sizing?: TileHostSizing }
  /** The tile's runtime is up and the tile document is loading. */
  | { tilesHost: 1; event: 'load' }
  /** The tile set a title. */
  | { tilesHost: 1; event: 'title'; title: string }
  /** The tile could not be loaded; the page shows `message` too. */
  | { tilesHost: 1; event: 'error'; message: string }
  /** A tiles-protocol message from the tile (https://dasl.ing/tp-data.html). */
  | { tilesHost: 1; event: 'protocol'; protocol: string; kind: string; payload?: unknown };

/** What an embedder may ask the host page to do. */
export type TileHostCommand =
  | { tilesHost: 1; action: 'send-protocol'; protocol: string; kind: string; payload?: unknown }
  | { tilesHost: 1; action: 'send-data'; payload?: unknown };

function asMessage (data: unknown): Record<string, unknown> | undefined {
  if (typeof data === 'string') {
    try { data = JSON.parse(data); }
    catch { return undefined; }
  }
  if (!data || typeof data !== 'object' || Array.isArray(data)) return undefined;
  const o = data as Record<string, unknown>;
  return o.tilesHost === TILE_HOST_VERSION ? o : undefined;
}

const str = (v: unknown): v is string => typeof v === 'string';

function asSizing (v: unknown): TileHostSizing | undefined {
  if (!v || typeof v !== 'object') return undefined;
  const { width, height } = v as { width?: unknown; height?: unknown };
  if (typeof width === 'number' && typeof height === 'number' && width > 0 && height > 0) return { width, height };
  return undefined;
}

/** A host event from a message's data (JSON string or object), or undefined for anything else. */
export function parseTileHostEvent (data: unknown): TileHostEvent | undefined {
  const o = asMessage(data);
  if (!o) return undefined;
  switch (o.event) {
    case 'manifest':
      if (!str(o.url)) return undefined;
      return {
        tilesHost: 1,
        event: 'manifest',
        url: o.url,
        name: str(o.name) ? o.name : undefined,
        description: str(o.description) ? o.description : undefined,
        sizing: asSizing(o.sizing),
      };
    case 'load':
      return { tilesHost: 1, event: 'load' };
    case 'title':
      return str(o.title) ? { tilesHost: 1, event: 'title', title: o.title } : undefined;
    case 'error':
      return str(o.message) ? { tilesHost: 1, event: 'error', message: o.message } : undefined;
    case 'protocol':
      return str(o.protocol) && str(o.kind)
        ? { tilesHost: 1, event: 'protocol', protocol: o.protocol, kind: o.kind, payload: o.payload }
        : undefined;
    default:
      return undefined;
  }
}

/** A command from a message's data (JSON string or object), or undefined for anything else. */
export function parseTileHostCommand (data: unknown): TileHostCommand | undefined {
  const o = asMessage(data);
  if (!o) return undefined;
  switch (o.action) {
    case 'send-protocol':
      return str(o.protocol) && str(o.kind)
        ? { tilesHost: 1, action: 'send-protocol', protocol: o.protocol, kind: o.kind, payload: o.payload }
        : undefined;
    case 'send-data':
      return { tilesHost: 1, action: 'send-data', payload: o.payload };
    default:
      return undefined;
  }
}
