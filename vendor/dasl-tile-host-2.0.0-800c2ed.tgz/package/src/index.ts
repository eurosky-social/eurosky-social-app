// The server side of the host page: the files, and the headers they ship
// with. The page itself is src/browser/host.ts, bundled into public/host.js.

import express from 'express';
import type { Response } from 'express';
import type { ServerResponse } from 'node:http';
import makeRel from './rel.js';

export * from './messages.js';

const rel = makeRel(import.meta.url);

/** The directory with the page's files, for serving them some other way. */
export const tileHostDir = rel('../public');

export interface TileHostOptions {
  /**
   * CSP `frame-src`: where the page may frame tiles from, i.e. the loading
   * server's origins. Default: any https: or http: origin, since the loading
   * server is a parameter of the page.
   */
  frameSrc?: string;
  /**
   * CSP `connect-src`: where the page may fetch tiles from (PDSes, DID
   * directories, CAR files). Default: any https: or http: origin.
   */
  connectSrc?: string;
}

/**
 * The headers the page is served with. The page's job is to be embedded, by a
 * WebView or an iframe, so there is deliberately no `frame-ancestors` and no
 * `X-Frame-Options`: whoever embeds it gets a tile, and nothing else, out of
 * it. The CSP confines the page itself; the tiles it runs are confined by the
 * loader and the loading server (see @dasl/tile-lexicon).
 */
export function tileHostHeaders (options: TileHostOptions = {}): Record<string, string> {
  const frameSrc = options.frameSrc ?? 'https: http:';
  const connectSrc = options.connectSrc ?? 'https: http:';
  return {
    'content-security-policy': [
      `default-src 'none'`,
      `script-src 'self'`,
      // The loader sizes the frame it creates with a style attribute.
      `style-src 'self' 'unsafe-inline'`,
      `img-src 'self' blob: data:`,
      `connect-src ${connectSrc}`,
      `frame-src ${frameSrc}`,
      `base-uri 'none'`,
      `form-action 'none'`,
      `object-src 'none'`,
    ].join('; '),
    'referrer-policy': 'no-referrer',
    'x-content-type-options': 'nosniff',
    'permissions-policy': 'interest-cohort=(), browsing-topics=()',
    'tk': 'N',
    'x-robots-tag': 'noindex, noai, noimageai',
    'cache-control': 'public, max-age=600',
  };
}

/**
 * An Express router serving the host page. Mount it on the site that also
 * runs the loading server, e.g. at `/host`, so that `load.<host>` is the
 * default loading server; or anywhere, and pass `?load=` to the page.
 */
export function createTileHostRouter (options: TileHostOptions = {}) {
  const headers = tileHostHeaders(options);
  const router = express.Router();
  router.use(express.static(tileHostDir, {
    index: 'index.html',
    setHeaders (res: ServerResponse) {
      (res as unknown as Response).set(headers);
    },
  }));
  return router;
}
