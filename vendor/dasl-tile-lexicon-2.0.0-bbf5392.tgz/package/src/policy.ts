// The security policy for tile origins, in one place.
//
// A tile runs on its own throwaway origin (<random>.<host>), where a service
// worker answers every request from the tile's own resources. These headers
// make that origin a dead end for anything else: the loading server sets
// `runtimeHeaders` on the loader runtime it serves there and `deadHeaders` on
// everything else, and the mothership passes every response the worker hands
// the tile through `tileResponseHeaders()`. Edit the policy here and every
// deployment picks it up.

import type { MaslHeaders } from './types.js';

/**
 * Sandbox flags for tile content. The runtime document carries them and every
 * frame a tile creates inherits them: no top navigation, no pointer lock, no
 * presentation, no storage-access escalation. Popups are allowed, and leave the
 * sandbox, so that links in a tile open as links do.
 */
export const tileSandbox = 'allow-downloads allow-forms allow-modals allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts';

// Where a tile origin may reach: itself (answered by the worker from the tile's
// own resources) and blob:/data: URLs. Never a remote origin.
const own = `'self' blob: data:`;

/**
 * CSP for tile documents: everything the worker serves. A tile owns its code,
 * so scripting is unrestricted (inline, eval, wasm); what is confined is where
 * bytes can go. `connect-src` catches fetch, XHR, WebSocket, EventSource,
 * beacons and WebTransport, which the worker cannot intercept; `frame-src`
 * and `form-action` catch navigations; `webrtc 'block'` will catch ICE once
 * browsers implement it (none do as of 2026, see the shuttle's WebRTC guard).
 * No `frame-ancestors`: it is checked against every ancestor, and the host
 * page framing the shuttle is another origin by design.
 */
export const tileCSP = [
  `default-src ${own}`,
  `script-src ${own} 'unsafe-inline' 'unsafe-eval' 'wasm-unsafe-eval'`,
  `style-src ${own} 'unsafe-inline'`,
  `connect-src ${own}`,
  `frame-src ${own}`,
  `form-action 'self'`,
  `object-src 'none'`,
  `base-uri 'self'`,
  `webrtc 'block'`,
  `sandbox ${tileSandbox}`,
].join('; ');

/**
 * CSP for the loader runtime (the shuttle page and its scripts). Tighter than
 * a tile's: the shuttle only ever loads its own scripts, frames `/`, and sets
 * an icon from a tile path.
 */
export const runtimeCSP = [
  `default-src 'self'`,
  `script-src 'self'`,
  `script-src-attr 'none'`,
  `style-src 'self' 'unsafe-inline'`,
  `img-src 'self' data:`,
  `connect-src 'none'`,
  `frame-src 'self'`,
  `worker-src 'self'`,
  `form-action 'none'`,
  `object-src 'none'`,
  `base-uri 'none'`,
  `manifest-src 'none'`,
  `webrtc 'block'`,
  `sandbox ${tileSandbox}`,
].join('; ');

/**
 * CSP for anything else a tile origin answers (404s, and whatever reaches the
 * network once a tile has unregistered its worker): a document that loads
 * nothing, runs nothing, cannot be framed, and has an opaque origin, so the
 * tile cannot script it.
 */
export const deadCSP = `default-src 'none'; form-action 'none'; base-uri 'none'; frame-ancestors 'none'; sandbox`;

/** Headers on every response the loading server itself makes on a tile origin. */
export const tileOriginHeaders: Record<string, string> = {
  'origin-agent-cluster': '?1',
  'referrer-policy': 'no-referrer',
  'permissions-policy': 'interest-cohort=(), browsing-topics=()',
  'cross-origin-resource-policy': 'cross-origin',
  'cross-origin-opener-policy': 'same-origin',
  'x-content-type-options': 'nosniff',
  'x-dns-prefetch-control': 'off',
  'tk': 'N',
  'x-robots-tag': 'noai, noimageai',
};

/** Headers for the loader runtime under `/.well-known/web-tiles/`. */
export const runtimeHeaders: Record<string, string> = {
  ...tileOriginHeaders,
  'service-worker-allowed': '/',
  'content-security-policy': runtimeCSP,
};

/** Headers for everything else on a tile origin. */
export const deadHeaders: Record<string, string> = {
  ...tileOriginHeaders,
  'content-security-policy': deadCSP,
};

// A Link header can preconnect or prefetch, which CSP does not govern, so only
// same-origin relative targets survive. Entries are `<target>; param, <target>; …`.
function localLinks (link: string): string | undefined {
  const kept = link
    .split(/,(?=\s*<)/)
    .map(s => s.trim())
    .filter((s) => {
      const target = s.match(/^<([^>]*)>/)?.[1];
      return !!target && !/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i.test(target);
    });
  return kept.length ? kept.join(', ') : undefined;
}

/**
 * The headers a tile document actually ships with: the resource's own headers,
 * with the policy added. A CSP the tile declares stays and is enforced alongside
 * (several policies only ever add restrictions). Speculation rules go, since they
 * can prefetch remote URLs, and so do Link targets that are not local paths.
 */
export function tileResponseHeaders (headers: MaslHeaders = {}): MaslHeaders {
  const { 'speculation-rules': _rules, link, 'content-security-policy': ownCSP, ...rest } = headers;
  const out: MaslHeaders = { 'referrer-policy': 'no-referrer', ...rest };
  const localLink = link && localLinks(link);
  if (localLink) out.link = localLink;
  out['content-security-policy'] = ownCSP ? `${ownCSP}, ${tileCSP}` : tileCSP;
  out['x-content-type-options'] = 'nosniff';
  out['x-dns-prefetch-control'] = 'off';
  return out;
}
