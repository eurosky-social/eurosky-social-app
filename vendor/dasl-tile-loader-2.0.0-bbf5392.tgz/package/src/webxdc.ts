
import JSZip from "jszip";
import mime from 'mime/lite';
import { parse } from 'smol-toml';
import { Tile } from "./index.js";
import type { TileMothership } from "./index.js";
import { ContentSchemeTileLoader, type LoaderOptions } from "./content-scheme.js";
import { MemoryPathLoader } from './memory.js';
import type { InMemoryMasl } from "@dasl/tile-lexicon";

// ### WebXDC (DeltaChat) Loader
// WebXDC works this way:
//  - It's a zip file with a bunch of files, you have to guess the media type.
//  - It must have an index.html at the root, which is the /.
//  - It may have icon.{png,jpg} at the root.
//  - It may have a manifest.toml (seriously), that may have a name entry and
//    one pointing to the source.
export class WebXDCTileLoader extends ContentSchemeTileLoader {
  constructor (schemes?: string[], options?: LoaderOptions) {
    super(schemes, options);
  }
  async processContent (zipData: ArrayBuffer, _: string, url: string, mothership: TileMothership): Promise<Tile | false> {
    const zip = new JSZip();
    try {
      await zip.loadAsync(zipData);
    }
    catch (e) {
      return false;
    }
    const manifest: InMemoryMasl = {
      resources: {},
    };
    // We could extract a description from index.html
    for (const path of Object.keys(zip.files)) {
      if (zip.files[path].dir) continue;
      const keyPath = (path === 'index.html') ? '/' : `/${path}`;
      if (/^icon\.(png|jpg)$/.test(path)) {
        if (!manifest.icons) manifest.icons = [];
        manifest.icons.push({ src: keyPath });
      }
      else if (path === 'manifest.toml') {
        const toml = parse(await zip.files[path].async('text'));
        manifest.name = (toml as { name?: string }).name;
      }
      const mediaType = mime.getType(path);
      manifest.resources[keyPath] = {
        src: await zip.files[path].async('arraybuffer'),
        'content-type': mediaType || undefined,
      };
    }
    // Add webxdc.js. NOTE: we need to make this pluggable so that it can actually
    // do some useful work.
    manifest.resources['/webxdc.js'] = {
      src: makeWebXDCAPI(),
      'content-type': 'application/javascript',
    };
    const loader = new MemoryPathLoader(manifest);
    return new Tile(mothership, url, manifest, loader);
  }
}

// This is the resource that implements webxdc.js. (Based on webxdc/hello.)
// Note that joinRealtimeChannel() is marked as optional, so we skip it.
// These are mostly stubs, e.g. sendToChat() just dumps to the console.
function makeWebXDCAPI ({ selfName = 'Dazzling Kitten', selfAddr }: { selfName?: string; selfAddr?: string } = {}): string {
  return [
    // self-func
    `window.webxdc = (() => {`,

    // utils
    `let updateListener = (_) => {};
    function getUpdates() {
      const updatesJSON = window.localStorage.getItem(updatesKey);
      return updatesJSON ? JSON.parse(updatesJSON) : [];
    }
    const updatesKey = "__xdcUpdatesKey__";
    window.addEventListener("storage", (event) => {
      if (event.key == null) {
        window.location.reload();
      } else if (event.key === updatesKey) {
        const updates = JSON.parse(event.newValue);
        const update = updates[updates.length - 1];
        update.max_serial = updates.length;
        console.log("[Webxdc] " + JSON.stringify(update));
        updateListener(update);
      } else if (event.key === ephemeralUpdateKey) {
        const [sender, update] = JSON.parse(event.newValue);
        // @ts-ignore: is_trashed() is private
        if (
          window.webxdc.selfAddr !== sender &&
          realtimeListener &&
          !realtimeListener.is_trashed()
        ) {
          realtimeListener.receive(Uint8Array.from(update));
        }
      }
    });`,

    // returned object
    `return {`,
    // selfies
    `selfAddr: "${selfAddr || crypto.randomUUID()}",
    selfName: "${selfName}",`,

    // updates
    `sendUpdate: (update) => {
      console.log('sendUpdate', update);
    },
    setUpdateListener: () => {
    },
    getAllUpdates: () => {
      console.log("[Webxdc] WARNING: getAllUpdates() is deprecated.");
      return Promise.resolve([]);
    },
    setUpdateListener: (cb, serial = 0) => {
      const updates = getUpdates();
      const maxSerial = updates.length;
      updates.forEach((update) => {
        if (update.serial > serial) {
          update.max_serial = maxSerial;
          cb(update);
        }
      });
      updateListener = cb;
      return Promise.resolve();
    },`,

    // sendToChat
    `sendToChat: async (content) => {
      if (!content.file && !content.text) {
        alert("🚨 Error: either file or text need to be set. (or both)");
        return Promise.reject(
          "Error from sendToChat: either file or text need to be set",
        );
      }
      console.info('sendToChat', content);
    },`,

    // importFiles
    `importFiles: (filters) => {
      const accept = [
        ...(filters.extensions || []),
        ...(filters.mimeTypes || []),
      ].join(",");
      const element = document.createElement("input");
      element.setAttribute('type', 'file');
      element.setAttribute('accept', accept);
      if (filters.multiple) element.setAttribute('multiple', 'multiple');
      const promise = new Promise((resolve) => {
        element.onchange = () => {
          const files = Array.from(element.files || []);
          document.body.removeChild(element);
          resolve(files);
        };
      });
      element.style.display = "none";
      document.body.appendChild(element);
      element.click();
      return promise;
    },`,
    // close object
    `};`,
    // close self-func
    `})();`
  ].join('\n');
}
