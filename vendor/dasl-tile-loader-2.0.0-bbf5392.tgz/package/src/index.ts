
/*
████████╗██╗██╗     ███████╗███████╗
╚══██╔══╝██║██║     ██╔════╝██╔════╝
   ██║   ██║██║     █████╗  ███████╗
   ██║   ██║██║     ██╔══╝  ╚════██║
   ██║   ██║███████╗███████╗███████║
   ╚═╝   ╚═╝╚══════╝╚══════╝╚══════╝
      •--~~~## MOTHERSHIP ##~~~--•

The tile-loading architecture has three levels that all communicate together:

- At the top, the MOTHERSHIP. This has access to things in the real world like
  fetching from the internet or reading from the file system. It's the interface
  to tile loading, it gets configured in ways that are appropriate for its
  context. This is the entry point: you give it a URL and it'll instantiate that
  tile. To the extent possible, this should contain all the intelligence and all
  the configurability so that the other components can be deployed in entirely
  generic ways.
- The mothership instantiates tiles by creating insulated contexts (a sandboxed
  iframe, an incognito window…) and loading a SHUTTLE in it. The role of the
  shuttle is to set up a service worker and an iframe to load the root of the
  tile into. It only exists because you need something to carry a service worker
  in. The only other thing that it does is (*drumroll*) shuttle messages back
  and forth between the worker and the mothership.
- The WORKER is dispatched on a shuttle to handle resource loading for a tile.
  Apart from allow-listing some paths for itself and the shuttle, it passes all
  requests up, which the shuttle then hands over to the mothership.
*/

import { el } from "./lib/el.js";
import { tileResponseHeaders } from "@dasl/tile-lexicon";
import type { AnyMasl, MaslHeaders, MaslResponse } from "@dasl/tile-lexicon";

export interface MothershipConfig {
  /** Host of the loading server (`load.webtil.es`), with a scheme and port when not https://. */
  loadDomain?: string;
  /**
   * Whether the shuttle spends the renderer's WebRTC budget before the tile
   * loads (the default). A host that blocks WebRTC itself (an Electron app with
   * the policy switches set, say) passes 'none' and skips the cost.
   */
  webrtcGuard?: 'exhaust' | 'none';
}

export interface TileLoader {
  load (url: string, mothership: TileMothership): Promise<Tile | false | undefined>;
}
export interface TilePathLoader {
  resolvePath (path: string): Promise<MaslResponse>;
}

const TILES_PFX = 'tiles-';
const SHUTTLE_PFX = 'tiles-shuttle-';
const SND_SHUTTLE_LOAD = `${SHUTTLE_PFX}load`;        // tell worker to roll
const RCV_SHUTTLE_READY = `${SHUTTLE_PFX}ready`;      // worker ready
const SND_SET_TITLE = `${SHUTTLE_PFX}set-title`;      // set the title
const SND_SET_ICON = `${SHUTTLE_PFX}set-icon`;        // set the icon
const WORKER_PFX = 'tiles-worker-';
const SND_WORKER_LOAD = `${WORKER_PFX}load`;          // tell worker to roll
const RCV_WORKER_READY = `${WORKER_PFX}ready`;        // worker ready
const RCV_WORKER_REQUEST = `${WORKER_PFX}request`;    // worker requested something
const SND_WORKER_RESPONSE = `${WORKER_PFX}response`;  // respond to a worker
const TILES_WARNING = `${TILES_PFX}warn`;             // worker warnings
const TILES_ERROR = `${TILES_PFX}error`;              // shuttle errors
// Tiles protocols (https://dasl.ing/tp-data.html and friends): the shuttle
// relays `tiles-protocol-up-<protocol>-<kind>` from the tile to us, and
// `tiles-protocol-down-<protocol>-<kind>` from us to the tile.
const PROTOCOL_UP = 'tiles-protocol-up-';
const PROTOCOL_DOWN = 'tiles-protocol-down-';

/** A tiles-protocol message from a tile: `protocol` ("data"), `kind` ("payload", "ready"), and its `payload`. */
export interface ProtocolEvent extends Event {
  protocol: string;
  kind: string;
  payload: unknown;
}
/** A tp-data message from a tile; `payload` is what the tile sent. */
export interface DataEvent extends Event {
  payload: unknown;
}

export class TileMothership {
  #loaders: TileLoader[] = [];
  #conf: MothershipConfig;
  #id2shuttle = new Map<string, HTMLIFrameElement>();
  #id2tile = new Map<string, Tile>();
  constructor (conf: MothershipConfig = {}) {
    this.#conf = conf;
  }
  init () {
    window.addEventListener('message', async (ev: MessageEvent) => {
      const { action } = ev.data || {};
      if (action === TILES_WARNING) {
        const { msg, id } = ev.data;
        console.warn(`[W:${id}]`, ...msg);
      }
      if (action === TILES_ERROR) {
        const { msg, id } = ev.data;
        console.error(`[S:${id}]`, ...msg);
      }
      else if (action === RCV_SHUTTLE_READY) {
        const { id } = ev.data;
        this.sendToShuttle(id, SND_WORKER_LOAD, { id });
      }
      else if (action === RCV_WORKER_READY) {
        const { id } = ev.data;
        const tile = this.#id2tile.get(id);
        if (!tile) throw new Error(`No tile shuttle with ID ${id}`);
        tile.dispatchEvent(new Event('load'));
      }
      else if (action === RCV_WORKER_REQUEST) {
        const { type, id, payload } = ev.data;
        if (type === 'resolve-path') {
          const { path, requestId } = payload;
          const tile = this.#id2tile.get(id);
          if (!tile) throw new Error(`No tile shuttle with ID ${id}`);
          const res = await tile.resolvePath(path);
          // Every document the worker serves, 404s included, carries the
          // policy: the tile can script anything on its origin, so nothing
          // on it may be unconfined.
          const response = res.ok
            ? { status: res.status, headers: this.hardenResponse(res.headers), body: res.body }
            : { status: res.status, headers: this.hardenResponse({ 'content-type': 'text/plain' }), body: undefined };
          this.sendToShuttle(id, SND_WORKER_RESPONSE, { requestId, response });
        }
      }
      else if (typeof action === 'string' && action.startsWith(PROTOCOL_UP)) {
        // Protocol messages carry no id: the shuttle window they come from
        // says which tile is talking, and nothing else gets to pretend.
        const tile = this.tileForWindow(ev.source);
        if (!tile) return;
        const rest = action.slice(PROTOCOL_UP.length);
        const dash = rest.indexOf('-');
        if (dash < 1) return;
        const protocol = rest.slice(0, dash);
        const kind = rest.slice(dash + 1);
        const { payload } = ev.data;
        tile.dispatchEvent(Object.assign(new Event('protocol'), { protocol, kind, payload }));
        if (protocol === 'data') {
          tile.dispatchEvent(Object.assign(new Event(kind === 'payload' ? 'data' : `data-${kind}`), { payload }));
        }
      }
    });
  }
  /**
   * The headers a tile document ships with: the resource's own, plus the
   * policy from @dasl/tile-lexicon. A host that wants more on every response
   * overrides this and calls super; nothing should ever return less.
   */
  hardenResponse (headers?: MaslHeaders): MaslHeaders {
    return tileResponseHeaders(headers);
  }
  tileForWindow (source: MessageEventSource | null): Tile | undefined {
    if (!source) return;
    for (const [id, ifr] of this.#id2shuttle) {
      if (ifr.contentWindow === source) return this.#id2tile.get(id);
    }
  }
  sendToShuttle (id: string, action: string, payload: unknown) {
    const ifr = this.#id2shuttle.get(id);
    if (!ifr) return console.error(`No shuttle for ID ${id}`);
    ifr.contentWindow?.postMessage({ id, action, payload }, '*');
  }
  registerShuttleFrame (ifr: HTMLIFrameElement, tile: Tile) {
    const id = crypto.randomUUID(); // we might want to make that pluggable
    this.#id2shuttle.set(id, ifr);
    this.#id2tile.set(id, tile);
    return id;
  }
  startShuttle (id: string) {
    this.sendToShuttle(id, SND_SHUTTLE_LOAD, { id, webrtcGuard: this.#conf.webrtcGuard ?? 'exhaust' });
  }
  // Adds a loader that will handle matching requests to load a tile.
  // - `loader` is an object that knows how to load a tile for a specific scheme
  //    (and types)
  addLoader (loader: TileLoader) {
    this.#loaders.push(loader);
  }
  // Remove using same reference.
  removeLoader (loader: TileLoader) {
    this.#loaders = this.#loaders.filter(ldr => ldr !== loader);
  }
  getLoadSource () {
    const domain = this.#conf.loadDomain || 'load.webtil.es';
    const base = /^https?:\/\//.test(domain) ? domain : `https://${domain}`;
    return new URL('/.well-known/web-tiles/', base).href;
  }
  // Load a tile.
  async loadTile (url: string): Promise<Tile | false> {
    for (const ldr of this.#loaders) {
      const tile = await ldr.load(url, this);
      if (tile) return tile;
    }
    return false;
  }
}

export class Tile extends EventTarget {
  #mothership: TileMothership;
  #url: string;
  #manifest: AnyMasl;
  #pathLoader: TilePathLoader;
  #shuttleId: string | undefined;
  constructor (mothership: TileMothership, url: string, manifest: AnyMasl, pathLoader: TilePathLoader) {
    super();
    this.#mothership = mothership;
    this.#url = url;
    this.#manifest = manifest;
    this.#pathLoader = pathLoader;
    this.addEventListener('load', () => {
      if (this.#manifest?.name) {
        const title = this.#manifest?.name;
        this.#mothership.sendToShuttle(this.#shuttleId!, SND_SET_TITLE, { title });
        const ev = new Event('title-change') as Event & { title?: string };
        ev.title = title;
        this.dispatchEvent(ev);
      }
      const icon = this.#manifest?.icons?.[0]?.src;
      if (icon) {
        this.#mothership.sendToShuttle(this.#shuttleId!, SND_SET_ICON, { path: icon });
      }
    });
  }
  get url (): string {
    return this.#url;
  }
  get manifest (): AnyMasl {
    return this.#manifest;
  }
  async resolvePath (path: string): Promise<MaslResponse> {
    const u = new URL(`fake:${path}`);
    return this.#pathLoader.resolvePath(u.pathname);
  }
  async renderCard (options?: { contentHeight?: number }): Promise<HTMLElement> {
    const card = el('div', { style: {
      border: '1px solid lightgrey',
      'border-radius': '3px',
      cursor: 'pointer',
    }});
    card.addEventListener('click', async () => {
      const tileRenderer = await this.renderContent(
        options?.contentHeight ||
        this.#manifest?.sizing?.height ||
        Math.max(card.offsetHeight, 300)
      );
      card.replaceWith(tileRenderer);
    });
    // XXX we always take the first, we could be smarter with sizes
    if (this.#manifest?.screenshots?.[0]?.src) {
      const res = await this.resolvePath(this.#manifest.screenshots[0].src);
      if (res.ok) {
        const blob = new Blob([res.body as BlobPart], { type: res.headers?.['content-type'] });
        const url = URL.createObjectURL(blob);
        el('div', { style: {
          'background-image': `url(${url})`,
          'background-size': 'cover',
          'background-position': '50%',
          'aspect-ratio': '16/9',
        }}, [], card);
      }
    }
    const title = el('div', { style: {
      padding: '0.5rem 1rem',
      display: 'flex',
      'align-items': 'center',
    }}, [], card);
    // XXX we always take the first, we could be smarter with sizes
    if (this.#manifest?.icons?.[0]?.src) {
      const res = await this.resolvePath(this.#manifest.icons[0].src);
      if (res.ok) {
        const blob = new Blob([res.body as BlobPart], { type: res.headers?.['content-type'] });
        const url = URL.createObjectURL(blob);
        el('img', { src: url, width: '48', height: '48', alt: 'icon', style: { 'padding-right': '0.5rem' } }, [], title);
      }
    }
    el('span', { style: { 'font-weight': 'bold' } }, [this.#manifest.name || 'Untitled Tile'], title);
    if (this.#manifest.description) {
      el('p', { style: { 'margin': '0.5rem 1rem 1rem 1rem' } }, [this.#manifest.description], card);
    }
    return card;
  }
  getLoadSource (): string {
    return this.#mothership.getLoadSource();
  }
  /**
   * Sends a tiles-protocol message down to the rendered tile. Messages the
   * tile sends up arrive as `protocol` events (and, for tp-data, as `data`
   * and `data-ready` events) on this object.
   */
  sendProtocol (protocol: string, kind: string, payload?: unknown) {
    if (!this.#shuttleId) throw new Error('The tile is not rendered yet.');
    this.#mothership.sendToShuttle(this.#shuttleId, `${PROTOCOL_DOWN}${protocol}-${kind}`, payload);
  }
  /** Sends a tp-data payload to the tile (https://dasl.ing/tp-data.html). */
  sendData (payload: unknown) {
    this.sendProtocol('data', 'payload', payload);
  }
  attachIframe (ifr: HTMLIFrameElement) {
    this.#shuttleId = this.#mothership.registerShuttleFrame(ifr, this);
    ifr.addEventListener('load', () => this.#mothership.startShuttle(this.#shuttleId!));
  }
  renderContent (height = 300): HTMLIFrameElement {
    const ifr = el('iframe', {
      src: this.#mothership.getLoadSource(),
      style: {
        display: 'block',
        width: '100%',
        height: `${height}px`,
        border: 'none',
      }
    }) as HTMLIFrameElement;
    this.attachIframe(ifr);
    return ifr;
  }
}
